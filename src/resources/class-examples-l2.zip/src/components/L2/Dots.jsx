import React from 'react';
import './Dots.css'

function Dots({numOfDots, selectedDot}) {

  let dots = [];
  for (let index = 0; index < numOfDots; index++) {
    dots.push(<div className={selectedDot === index + 1 ? "selected" : ""}></div>)
  }

  return (
    <div className="dots">
      {dots}
    </div>
  );
}

export default Dots;