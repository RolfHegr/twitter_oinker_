import React, {useState} from 'react';

function Counter(props) {
  const [counter, setCounter] = useState(0);

  function increase() {
    setCounter(counter + 1);
  }


  return (
    <div>
      <h1>Hello Counter</h1>
      <p>Hello {counter}</p>
      <button onClick={increase}>Increase</button>
    </div>
  );
}

export default Counter;

