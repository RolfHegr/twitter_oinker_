import React from 'react';
import './Title.css'

function Title({text, bgColor, isCenter}) {

  const myStyle = {
    backgroundColor: bgColor
  }

  return (
    <h1 className={isCenter ? "center" : ""} style={myStyle}>{text}</h1>
  );
}

export default Title;