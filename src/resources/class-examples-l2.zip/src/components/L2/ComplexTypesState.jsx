import React, {useState} from 'react';

function ComplexTypesState(props) {
  const [numbers, setNumbers] = useState([1, 4, 6])

  function addNumber() {

    // const newNumbers = [...numbers];
    // newNumbers.push(77);
    // setNumbers(newNumbers);

    setNumbers(numbers.concat(77));


  }

  return (
    <div>
      <h2>Numbers</h2>
      <ul>
        {numbers.map((num, index) => <li key={index}>{num}</li>)}
        </ul>
      <button onClick={addNumber}>Add Number</button>
    </div>
  );
}

export default ComplexTypesState;