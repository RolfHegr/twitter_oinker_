import React from "react";
import "./JSXExamples.css";

function JSXExamples(props) {
  let x = 11;

  function getUnits(num) {
    return num % 10;
  }

  let googleURL = "http://www.google.com";

  let jsxVar;
  if (x <= 10) {
    jsxVar = <h4>small</h4>;
  } else {
    jsxVar = <h1>Big</h1>;
  }

  const shoppingItems = ["Bread", "Eggs", "Milk"];

  const myStyle = {
    backgroundColor: "green",
    textAlign: "center",
  };

  function someEvent() {
    alert('hi')
  }

  const classes = ["red", "bg-green"];

  return (
    <div>
      <div className="red">{x}</div>
      <div style={myStyle}> {x + 10}</div>
      <div className={classes.join(" ")}>{getUnits(463)}</div>
      <a href={googleURL} target="_blank" rel="noreferrer">
        Google
      </a>
      {x > 10 ? <h1>I am a big number</h1> : <h4>I am a small number</h4>}
      {jsxVar}
      <ul>
        {shoppingItems.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
      {shoppingItems}
      <button onClick={someEvent}>Click Me</button>
      <button onClick={() => alert('hi inline')}>Click Me 2</button>
    </div>
  );
}

export default JSXExamples;
