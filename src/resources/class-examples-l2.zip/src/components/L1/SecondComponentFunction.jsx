import React from "react";

// function SecondComponentFunction(props) {
//   return (
//     <div>
//       <img
//         src="https://kerenagam.co.il/wp-content/uploads/2021/06/Thinking-of-getting-a-cat.png"
//         alt="Cat"
//       />
//     </div>
//   );
// }

const SecondComponentFunction = () => (
  <div>
    <img
      src="https://kerenagam.co.il/wp-content/uploads/2021/06/Thinking-of-getting-a-cat.png"
      alt="Cat"
    />
  </div>
);

export default SecondComponentFunction;
