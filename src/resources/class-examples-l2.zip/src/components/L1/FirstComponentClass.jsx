import React from "react";
import SecondComponentFunction from "./SecondComponentFunction";

class FirstComponentClass extends React.Component {
  render() {
    return (
      <div>
        <h1>My First React Component</h1>
        <SecondComponentFunction />
        <SecondComponentFunction />
      </div>
    );
  }
}

export default FirstComponentClass;
