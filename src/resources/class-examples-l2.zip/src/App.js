import "./App.css";
import FirstComponentClass from "./components/L1/FirstComponentClass";
import JSXExamples from "./components/L1/JSXExamples";
import Title from "./components/L2/Title";
import Dots from "./components/L2/Dots";
import Counter from "./components/L2/Counter";
import ComplexTypesState from "./components/L2/ComplexTypesState";

function App() {
  return (
    <div className="App">

      <Title text="Hello React Props!" bgColor="pink" isCenter/>
      <Title text="Anoter Title" bgColor="red"/>

      <Dots numOfDots={5} selectedDot={2}/>

      <Counter />

      <ComplexTypesState/>

      {/* <JSXExamples />
      <FirstComponentClass /> */}
    </div>
  );
}

export default App;
