import React from "react";

const UsersContext = React.createContext(null)

export default UsersContext;