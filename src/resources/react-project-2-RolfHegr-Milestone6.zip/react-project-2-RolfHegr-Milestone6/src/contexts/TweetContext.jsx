import React from "react";

const TweetContext = React.createContext(null);

export default TweetContext;
