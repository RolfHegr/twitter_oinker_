import React from "react";

export default function NotFoundPage() {
  return (
    <div className="c-Profile">
      <h1>404 Error - Page Not Found</h1>
    </div>
  )
}
